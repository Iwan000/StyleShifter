import { Sparkles } from 'lucide-react';
import { Button } from './ui/button';

interface TransformationPreviewProps {
  originalText: string;
  transformedText: string;
  modelName: string;
  onApply: () => void;
  onCancel: () => void;
}

export function TransformationPreview({
  originalText,
  transformedText,
  modelName,
  onApply,
  onCancel,
}: TransformationPreviewProps) {
  return (
    <div className="bg-blue-50 border-t border-blue-200">
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex items-start gap-2 mb-3">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-sm text-blue-900">Transformed with</span>
              <span className="text-sm text-blue-600">{modelName}</span>
            </div>
            <div className="bg-white rounded-xl border border-blue-200 p-4 mb-2">
              <p className="text-gray-900 mb-2">{transformedText}</p>
              <p className="text-xs text-gray-500">Original: {originalText}</p>
            </div>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={onCancel}
                className="text-gray-700 border-gray-300"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={onApply}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Apply & Send
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

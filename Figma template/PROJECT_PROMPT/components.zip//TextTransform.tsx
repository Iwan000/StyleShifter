import { useState } from 'react';
import { Upload, X, FileText, Wand2, Copy, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Model } from '../App';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface TextTransformProps {
  onClose?: () => void;
  models: Model[];
  transformText: (text: string, modelId: string | null) => string;
  showHeader?: boolean;
}

export function TextTransform({ onClose, models, transformText, showHeader = true }: TextTransformProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isTransforming, setIsTransforming] = useState(false);
  const [inputText, setInputText] = useState('');
  const [transformedText, setTransformedText] = useState('');
  const [selectedModelId, setSelectedModelId] = useState<string>('');
  const [activeTab, setActiveTab] = useState('text');
  const [copied, setCopied] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      setSelectedFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Simulate PDF text extraction
      const mockPdfText = 'This is the extracted text from the PDF document. It contains multiple sentences that demonstrate the writing style and content of the document.';
      setInputText(mockPdfText);
    }
  };

  const handleTransform = () => {
    if (!selectedModelId || !inputText.trim()) return;
    
    setIsTransforming(true);
    setCopied(false);
    
    // Simulate transformation
    setTimeout(() => {
      const transformed = transformText(inputText, selectedModelId);
      setTransformedText(transformed);
      setIsTransforming(false);
    }, 1000);
  };

  const handleCopy = async () => {
    if (!transformedText) return;
    
    try {
      await navigator.clipboard.writeText(transformedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const canTransform = selectedModelId && inputText.trim().length > 0;

  return (
    <div className={showHeader ? "h-screen bg-gray-50 flex flex-col" : "h-full bg-gray-50 flex flex-col"}>
      {showHeader && (
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
          <h1 className="text-gray-900">Transform Test</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto">
          <Alert className="mb-6">
            <AlertDescription>
              Select a trained model and provide text to transform it using the learned writing style.
            </AlertDescription>
          </Alert>

          {/* Model Selection */}
          <div className="mb-6 bg-white rounded-xl p-4 border border-gray-200">
            <Label htmlFor="model-select" className="mb-2 block">
              Select Model
            </Label>
            <Select value={selectedModelId} onValueChange={setSelectedModelId}>
              <SelectTrigger id="model-select" className="w-full">
                <SelectValue placeholder="Choose a model to transform text" />
              </SelectTrigger>
              <SelectContent>
                {models.length === 0 ? (
                  <div className="px-2 py-6 text-center text-sm text-gray-500">
                    No models available. Train a model first.
                  </div>
                ) : (
                  models.map((model) => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input Section */}
            <div className="bg-white rounded-xl p-4 border border-gray-200">
              <h3 className="text-sm text-gray-700 mb-4">Input</h3>
              
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="text">Text Input</TabsTrigger>
                  <TabsTrigger value="pdf">PDF Upload</TabsTrigger>
                </TabsList>

                <TabsContent value="text" className="mt-0">
                  <Textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Enter the text you want to transform..."
                    className="min-h-[300px] resize-none"
                  />
                </TabsContent>

                <TabsContent value="pdf" className="mt-0">
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
                      isDragging
                        ? 'border-blue-600 bg-blue-50'
                        : selectedFile
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-300 bg-white'
                    }`}
                  >
                    {selectedFile ? (
                      <div className="flex flex-col items-center gap-3">
                        <FileText className="w-12 h-12 text-green-600" />
                        <div>
                          <p className="text-sm text-gray-900">{selectedFile.name}</p>
                          <p className="text-xs text-gray-500">
                            {(selectedFile.size / 1024).toFixed(2)} KB
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedFile(null);
                            setInputText('');
                          }}
                        >
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-3">
                        <Upload className="w-12 h-12 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-900 mb-1">
                            Drag and drop your PDF
                          </p>
                          <p className="text-xs text-gray-500">or</p>
                        </div>
                        <label>
                          <input
                            type="file"
                            accept=".pdf"
                            onChange={handleFileSelect}
                            className="hidden"
                          />
                          <Button variant="outline" size="sm" asChild>
                            <span>Browse Files</span>
                          </Button>
                        </label>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Output Section */}
            <div className="bg-white rounded-xl p-4 border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm text-gray-700">Transformed Output</h3>
                {transformedText && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopy}
                    className="gap-2"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copy
                      </>
                    )}
                  </Button>
                )}
              </div>
              
              {transformedText ? (
                <div className="min-h-[300px] p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-gray-900 whitespace-pre-wrap">{transformedText}</p>
                </div>
              ) : (
                <div className="min-h-[300px] flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <Wand2 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">
                      Transformed text will appear here
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showHeader && (
        <div className="bg-white border-t border-gray-200 px-4 py-4">
          <div className="max-w-4xl mx-auto">
            <Button
              onClick={handleTransform}
              disabled={!canTransform || isTransforming}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isTransforming ? 'Transforming...' : 'Transform Text'}
            </Button>
          </div>
        </div>
      )}
      {!showHeader && (
        <div className="p-4">
          <div className="max-w-4xl mx-auto">
            <Button
              onClick={handleTransform}
              disabled={!canTransform || isTransforming}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isTransforming ? 'Transforming...' : 'Transform Text'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

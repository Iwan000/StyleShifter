import { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface TrainingSuccessProps {
  onSave: (modelName: string) => void;
  onTrainAnother: () => void;
}

const exampleTransformations = [
  'The gentle whisper of the morning breeze dances through the trees',
  'In the quietude of twilight, dreams begin to take their flight',
  'Like stars that shimmer in the velvet night sky above'
];

export function TrainingSuccess({ onSave, onTrainAnother }: TrainingSuccessProps) {
  const [modelName, setModelName] = useState('');

  const handleSave = () => {
    if (modelName.trim()) {
      onSave(modelName);
    }
  };

  return (
    <div className="h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-gray-900 mb-2">Training Complete!</h2>
            <p className="text-gray-600">
              Your model has been successfully trained and is ready to use.
            </p>
          </div>

          <div className="mb-6">
            <h3 className="text-sm text-gray-700 mb-3">Example Transformations</h3>
            <div className="space-y-2">
              {exampleTransformations.map((example, index) => (
                <div
                  key={index}
                  className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3"
                >
                  <p className="text-sm text-blue-900">{example}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <Label htmlFor="modelName" className="mb-2 block">
              Model Name
            </Label>
            <Input
              id="modelName"
              value={modelName}
              onChange={(e) => setModelName(e.target.value)}
              placeholder="e.g., Poetic Writer, Professional Tone, etc."
              className="w-full"
            />
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onTrainAnother}
              className="flex-1"
            >
              Train Another
            </Button>
            <Button
              onClick={handleSave}
              disabled={!modelName.trim()}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              Save & Use Model
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

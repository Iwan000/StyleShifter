import { Sparkles } from 'lucide-react';
import { Message } from '../App';
import { Badge } from './ui/badge';

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[70%] ${message.isUser ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
        <div
          className={`rounded-2xl px-4 py-2 ${
            message.isUser
              ? 'bg-blue-600 text-white'
              : 'bg-white text-gray-900 border border-gray-200'
          }`}
        >
          <p className="break-words">{message.text}</p>
        </div>
        <div className="flex items-center gap-2 px-2">
          <span className="text-xs text-gray-500">{formatTime(message.timestamp)}</span>
          {message.modelName && (
            <Badge variant="secondary" className="h-5 px-1.5 text-xs flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              {message.modelName}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}

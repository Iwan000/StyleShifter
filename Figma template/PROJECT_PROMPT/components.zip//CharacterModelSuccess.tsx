import { useState } from 'react';
import { Sparkles, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface Character {
  id: string;
  name: string;
  description: string;
  source: string;
}

interface CharacterModelSuccessProps {
  character: Character;
  onSave: (modelName: string) => void;
  onBrowseAnother: () => void;
}

// Mock transformation examples based on character
const getExampleTransformations = (characterName: string): { original: string; transformed: string }[] => {
  const examples: Record<string, { original: string; transformed: string }[]> = {
    'Sherlock Holmes': [
      {
        original: "I think this is interesting.",
        transformed: "Elementary! The matter presents itself as most intriguing, I deduce."
      },
      {
        original: "Let's figure this out.",
        transformed: "Come, Watson! The game is afoot. We shall apply logic and observation to unravel this mystery."
      }
    ],
    'Yoda': [
      {
        original: "We should try harder.",
        transformed: "Try harder, we must. Do or do not, there is no try."
      },
      {
        original: "This is very important.",
        transformed: "Important this is, yes. Mmm. Much wisdom it holds."
      }
    ],
    'Shakespeare': [
      {
        original: "Good morning! How are you?",
        transformed: "Fair morrow to thee! Pray tell, how doth thy spirit fare this blessed day?"
      }
    ],
    'Tony Stark': [
      {
        original: "I can do this.",
        transformed: "Please. I'm a genius, billionaire, playboy, philanthropist. This? This is Tuesday for me."
      }
    ],
    'Dumbledore': [
      {
        original: "Don't worry, it will be okay.",
        transformed: "Ah, my dear friend. Happiness can be found even in the darkest of times, if one only remembers to turn on the light."
      }
    ],
  };

  return examples[characterName] || [
    {
      original: "Hello, how are you?",
      transformed: `[Speaking as ${characterName}] Greetings! How do you fare?`
    }
  ];
};

export function CharacterModelSuccess({ 
  character, 
  onSave, 
  onBrowseAnother 
}: CharacterModelSuccessProps) {
  const [modelName, setModelName] = useState(character.name);
  const examples = getExampleTransformations(character.name);

  const handleSave = () => {
    if (modelName.trim()) {
      onSave(modelName);
    }
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <h1 className="text-gray-900">Character Model Created</h1>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h2 className="text-gray-900 mb-1">Model Created Successfully!</h2>
                <p className="text-sm text-gray-600">
                  Based on {character.name} from {character.source}
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              {character.description}
            </p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-blue-600" />
              <h3 className="text-gray-900">Example Transformations</h3>
            </div>
            
            <div className="space-y-4">
              {examples.map((example, index) => (
                <div key={index} className="space-y-2">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500 mb-1">Original:</p>
                    <p className="text-sm text-gray-700">{example.original}</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-3">
                    <p className="text-xs text-blue-600 mb-1">As {character.name}:</p>
                    <p className="text-sm text-gray-900">{example.transformed}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
            <Label htmlFor="modelName" className="mb-2 block">
              Model Name
            </Label>
            <Input
              id="modelName"
              value={modelName}
              onChange={(e) => setModelName(e.target.value)}
              placeholder="e.g., Sherlock Holmes Style"
              className="w-full"
            />
            <p className="text-xs text-gray-500 mt-2">
              You can customize the model name or keep the character's name.
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onBrowseAnother}
              className="flex-1"
            >
              Browse Another
            </Button>
            <Button
              onClick={handleSave}
              disabled={!modelName.trim()}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              Save & Use Model
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

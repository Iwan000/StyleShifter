import { useState } from 'react';
import { X, Plus, Wand2, GraduationCap, Trash2, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Model } from '../App';
import { TextTransform } from './TextTransform';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface ModelManagementProps {
  onClose: () => void;
  models: Model[];
  onTrainNew: () => void;
  onBrowseCharacters: () => void;
  onDeleteModel: (modelId: string) => void;
  transformText: (text: string, modelId: string | null) => string;
}

export function ModelManagement({ 
  onClose, 
  models, 
  onTrainNew,
  onBrowseCharacters,
  onDeleteModel,
  transformText 
}: ModelManagementProps) {
  const [activeTab, setActiveTab] = useState('train');
  const [modelToDelete, setModelToDelete] = useState<string | null>(null);

  const handleDeleteClick = (modelId: string) => {
    setModelToDelete(modelId);
  };

  const handleConfirmDelete = () => {
    if (modelToDelete) {
      onDeleteModel(modelToDelete);
      setModelToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setModelToDelete(null);
  };

  const modelToDeleteName = models.find(m => m.id === modelToDelete)?.name;

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <h1 className="text-gray-900">StyleShifter</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="bg-white border-b border-gray-200">
          <TabsList className="w-full justify-start h-12 bg-transparent rounded-none border-b-0">
            <TabsTrigger 
              value="train" 
              className="gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none"
            >
              <Plus className="w-4 h-4" />
              New Model
            </TabsTrigger>
            <TabsTrigger 
              value="transform" 
              className="gap-2 data-[state=active]:border-b-2 data-[state=active]:border-blue-600 rounded-none"
            >
              <Wand2 className="w-4 h-4" />
              Transform Test
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="train" className="flex-1 overflow-y-auto p-4 mt-0">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6 grid grid-cols-2 gap-3">
              <Button
                onClick={onBrowseCharacters}
                variant="outline"
                className="gap-2 border-blue-600 text-blue-600 hover:bg-blue-50"
              >
                <Users className="w-5 h-5" />
                Browse Characters
              </Button>
              <Button
                onClick={onTrainNew}
                className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
              >
                <Plus className="w-5 h-5" />
                Train New Model
              </Button>
            </div>

            <div className="space-y-3">
              <h2 className="text-sm text-gray-700">Your Models ({models.length})</h2>
              
              {models.length === 0 ? (
                <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                  <GraduationCap className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-gray-900 mb-2">No Models Yet</h3>
                  <p className="text-sm text-gray-500 mb-6">
                    Train your first model to get started with AI-powered text transformation.
                  </p>
                  <Button
                    onClick={onTrainNew}
                    variant="outline"
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Train Your First Model
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  {models.map((model) => (
                    <div
                      key={model.id}
                      className="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between hover:border-blue-300 transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="text-gray-900">{model.name}</h3>
                        {model.lastUsed && (
                          <p className="text-xs text-gray-500 mt-1">
                            Last used: {new Date(model.lastUsed).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteClick(model.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="transform" className="flex-1 mt-0">
          <TextTransform
            models={models}
            transformText={transformText}
            showHeader={false}
          />
        </TabsContent>
      </Tabs>

      <AlertDialog open={!!modelToDelete} onOpenChange={() => setModelToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Model</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{modelToDeleteName}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelDelete}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

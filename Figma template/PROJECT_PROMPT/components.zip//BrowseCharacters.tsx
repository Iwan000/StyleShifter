import { useState } from 'react';
import { X, Search, Sparkles, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Skeleton } from './ui/skeleton';

interface Character {
  id: string;
  name: string;
  description: string;
  source: string;
}

interface BrowseCharactersProps {
  onClose: () => void;
  onSelectCharacter: (character: Character) => void;
}

// Mock character database - in a real app, this would be an API call
const mockSearchCharacters = (query: string): Character[] => {
  const allCharacters: Character[] = [
    {
      id: '1',
      name: 'Sherlock Holmes',
      description: 'Brilliant detective known for logical deduction and keen observation',
      source: 'Arthur Conan Doyle novels'
    },
    {
      id: '2',
      name: 'Yoda',
      description: 'Wise Jedi Master with distinctive inverted sentence structure',
      source: 'Star Wars'
    },
    {
      id: '3',
      name: 'Shakespeare',
      description: 'Elizabethan poet and playwright with elaborate poetic language',
      source: 'Historical figure'
    },
    {
      id: '4',
      name: 'Gandalf',
      description: 'Ancient wizard with formal, archaic speech patterns',
      source: 'The Lord of the Rings'
    },
    {
      id: '5',
      name: 'Tony Stark',
      description: 'Genius inventor with witty, sarcastic, and confident speech',
      source: 'Marvel Comics / MCU'
    },
    {
      id: '6',
      name: 'Elizabeth Bennet',
      description: 'Witty and intelligent with refined Regency-era English',
      source: 'Pride and Prejudice'
    },
    {
      id: '7',
      name: 'Dumbledore',
      description: 'Wise headmaster with gentle, thoughtful and often cryptic speech',
      source: 'Harry Potter'
    },
    {
      id: '8',
      name: 'Hermione Granger',
      description: 'Highly intelligent and articulate with precise vocabulary',
      source: 'Harry Potter'
    },
    {
      id: '9',
      name: 'Darth Vader',
      description: 'Commanding presence with dramatic, authoritative speech',
      source: 'Star Wars'
    },
    {
      id: '10',
      name: 'Sheldon Cooper',
      description: 'Highly intelligent physicist with literal and pedantic speech',
      source: 'The Big Bang Theory'
    }
  ];

  const lowerQuery = query.toLowerCase().trim();
  if (!lowerQuery) return [];

  return allCharacters.filter(char => 
    char.name.toLowerCase().includes(lowerQuery) ||
    char.description.toLowerCase().includes(lowerQuery) ||
    char.source.toLowerCase().includes(lowerQuery)
  );
};

export function BrowseCharacters({ onClose, onSelectCharacter }: BrowseCharactersProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Character[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setHasSearched(false);

    // Simulate API delay
    setTimeout(() => {
      const results = mockSearchCharacters(searchQuery);
      setSearchResults(results);
      setIsSearching(false);
      setHasSearched(true);
    }, 800);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleSelectCharacter = (character: Character) => {
    onSelectCharacter(character);
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <h1 className="text-gray-900">Browse Characters</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto">
          <Alert className="mb-6">
            <Sparkles className="h-4 w-4" />
            <AlertDescription>
              Search for famous characters to create a model based on their unique speaking style.
            </AlertDescription>
          </Alert>

          <div className="mb-6 bg-white rounded-xl p-6 border border-gray-200">
            <Label htmlFor="character-search" className="mb-2 block">
              Search Character
            </Label>
            <div className="flex gap-2">
              <Input
                id="character-search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="e.g., Sherlock Holmes, Yoda, Shakespeare..."
                className="flex-1"
              />
              <Button
                onClick={handleSearch}
                disabled={!searchQuery.trim() || isSearching}
                className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
              >
                <Search className="w-4 h-4" />
                Search
              </Button>
            </div>
          </div>

          {isSearching && (
            <div className="space-y-3">
              <p className="text-sm text-gray-600 mb-4">Searching characters...</p>
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl border border-gray-200 p-4">
                  <Skeleton className="h-5 w-48 mb-2" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ))}
            </div>
          )}

          {!isSearching && hasSearched && searchResults !== null && (
            <>
              {searchResults.length === 0 ? (
                <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                  <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-gray-900 mb-2">No Characters Found</h3>
                  <p className="text-sm text-gray-500">
                    We couldn't find any characters matching "{searchQuery}". Try searching for another character.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <h2 className="text-sm text-gray-700">
                    Found {searchResults.length} character{searchResults.length !== 1 ? 's' : ''}
                  </h2>
                  {searchResults.map((character) => (
                    <button
                      key={character.id}
                      onClick={() => handleSelectCharacter(character)}
                      className="w-full bg-white rounded-xl border border-gray-200 p-4 text-left hover:border-blue-400 hover:shadow-sm transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-gray-900 mb-1">{character.name}</h3>
                          <p className="text-sm text-gray-600 mb-2">{character.description}</p>
                          <p className="text-xs text-gray-500">From: {character.source}</p>
                        </div>
                        <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0 ml-3" />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}

          {!isSearching && !hasSearched && (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
              <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-gray-900 mb-2">Start Searching</h3>
              <p className="text-sm text-gray-500">
                Enter a character name above to find their speaking style.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { Check, Plus, Settings, Sparkles } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Button } from './ui/button';
import { Model } from '../App';
import { Separator } from './ui/separator';

interface ModelSelectorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  models: Model[];
  pinnedModelIds: string[];
  selectedModelId: string | null;
  selectedModelName: string;
  onSelectModel: (modelId: string | null) => void;
  onTrainNewModel: () => void;
  onManagePinned: () => void;
}

export function ModelSelector({
  open,
  onOpenChange,
  models,
  pinnedModelIds,
  selectedModelId,
  selectedModelName,
  onSelectModel,
  onTrainNewModel,
  onManagePinned,
}: ModelSelectorProps) {
  const pinnedModels = models.filter(model => pinnedModelIds.includes(model.id));

  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 px-2 text-gray-700 hover:bg-gray-100"
        >
          <Sparkles className="w-4 h-4 mr-1.5 text-blue-600" />
          {selectedModelName}
        </Button>
      </PopoverTrigger>
      <PopoverContent 
        className="w-80 p-0" 
        align="start"
        side="top"
        sideOffset={8}
      >
        <div className="p-2">
          <button
            onClick={() => onSelectModel(null)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <span className="text-gray-700">None (Original Text)</span>
            {selectedModelId === null && (
              <Check className="w-4 h-4 text-blue-600" />
            )}
          </button>

          {pinnedModels.length > 0 && (
            <>
              <Separator className="my-2" />
              
              <div className="px-3 py-1.5">
                <span className="text-xs text-gray-500">Quick Access</span>
              </div>

              {pinnedModels.map((model) => (
                <button
                  key={model.id}
                  onClick={() => onSelectModel(model.id)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="text-gray-700">{model.name}</span>
                  {selectedModelId === model.id && (
                    <Check className="w-4 h-4 text-blue-600" />
                  )}
                </button>
              ))}
            </>
          )}

          <Separator className="my-2" />

          <button
            onClick={onManagePinned}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 transition-colors text-blue-600"
          >
            <Settings className="w-4 h-4" />
            <span>Manage Quick Access</span>
          </button>

          <button
            onClick={onTrainNewModel}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 transition-colors text-blue-600"
          >
            <Plus className="w-4 h-4" />
            <span>Open StyleShifter</span>
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

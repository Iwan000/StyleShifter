import { useState } from 'react';
import { X, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Model } from '../App';
import { ScrollArea } from './ui/scroll-area';

interface PinnedModelsManagerProps {
  models: Model[];
  pinnedModelIds: string[];
  onClose: () => void;
  onSave: (pinnedIds: string[]) => void;
}

export function PinnedModelsManager({
  models,
  pinnedModelIds,
  onClose,
  onSave,
}: PinnedModelsManagerProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>(pinnedModelIds);

  const toggleModel = (modelId: string) => {
    if (selectedIds.includes(modelId)) {
      setSelectedIds(selectedIds.filter(id => id !== modelId));
    } else {
      if (selectedIds.length < 3) {
        setSelectedIds([...selectedIds, modelId]);
      }
    }
  };

  const handleSave = () => {
    onSave(selectedIds);
    onClose();
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <h1 className="text-gray-900">Manage Quick Access Models</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col p-4">
        <div className="max-w-2xl mx-auto w-full flex-1 flex flex-col">
          <div className="mb-4">
            <p className="text-gray-700">
              Select up to 3 models to show in quick access
            </p>
            <p className="text-sm text-gray-500 mt-1">
              Selected: {selectedIds.length} / 3
            </p>
          </div>

          <ScrollArea className="flex-1 bg-white rounded-xl border border-gray-200">
            <div className="p-2">
              {models.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  No models available. Train a model first.
                </div>
              ) : (
                <div className="space-y-1">
                  {models.map((model) => {
                    const isSelected = selectedIds.includes(model.id);
                    const position = selectedIds.indexOf(model.id);

                    return (
                      <button
                        key={model.id}
                        onClick={() => toggleModel(model.id)}
                        className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors ${
                          isSelected
                            ? 'bg-blue-50 border-2 border-blue-600'
                            : 'bg-white border-2 border-transparent hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              isSelected
                                ? 'bg-blue-600 text-white'
                                : 'bg-gray-200 text-gray-400'
                            }`}
                          >
                            {isSelected ? (
                              <span className="text-xs">{position + 1}</span>
                            ) : (
                              <Star className="w-3.5 h-3.5" />
                            )}
                          </div>
                          <span className="text-gray-900">{model.name}</span>
                        </div>
                        {isSelected && (
                          <Star className="w-5 h-5 text-blue-600 fill-blue-600" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>

      <div className="bg-white border-t border-gray-200 px-4 py-4">
        <div className="max-w-2xl mx-auto flex gap-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
          >
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
}

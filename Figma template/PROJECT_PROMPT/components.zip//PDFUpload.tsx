import { useState } from 'react';
import { Upload, X, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';

interface PDFUploadProps {
  onClose: () => void;
  onTrainingComplete: () => void;
}

export function PDFUpload({ onClose, onTrainingComplete }: PDFUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingText, setTrainingText] = useState('');
  const [activeTab, setActiveTab] = useState('text');

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      setSelectedFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleTrain = () => {
    if (activeTab === 'pdf' && !selectedFile) return;
    if (activeTab === 'text' && !trainingText.trim()) return;
    
    setIsTraining(true);
    
    // Simulate training
    setTimeout(() => {
      onTrainingComplete();
    }, 2000);
  };

  const canTrain = activeTab === 'pdf' ? !!selectedFile : trainingText.trim().length > 0;

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <h1 className="text-gray-900">Create New Model</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-2xl mx-auto">
          <Alert className="mb-6">
            <AlertDescription>
              Provide examples of the writing style you want to replicate. 
              The model will learn from the text patterns and apply them to your messages.
            </AlertDescription>
          </Alert>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="text">Text Input</TabsTrigger>
              <TabsTrigger value="pdf">PDF Upload</TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="mt-0">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="training-text" className="mb-2 block">
                    Training Text
                  </Label>
                  <Textarea
                    id="training-text"
                    value={trainingText}
                    onChange={(e) => setTrainingText(e.target.value)}
                    placeholder="Paste or type examples of the writing style you want to replicate. Include multiple sentences or paragraphs for better results..."
                    className="min-h-[300px] resize-none"
                  />
                </div>
                <p className="text-sm text-gray-500">
                  Tip: Provide at least 3-5 sentences for better model accuracy.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="pdf" className="mt-0">
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
                  isDragging
                    ? 'border-blue-600 bg-blue-50'
                    : selectedFile
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 bg-white'
                }`}
              >
                {selectedFile ? (
                  <div className="flex flex-col items-center gap-4">
                    <FileText className="w-16 h-16 text-green-600" />
                    <div>
                      <p className="text-gray-900">{selectedFile.name}</p>
                      <p className="text-sm text-gray-500">
                        {(selectedFile.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedFile(null)}
                    >
                      Remove
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-4">
                    <Upload className="w-16 h-16 text-gray-400" />
                    <div>
                      <p className="text-gray-900 mb-1">
                        Drag and drop your PDF here
                      </p>
                      <p className="text-sm text-gray-500">or</p>
                    </div>
                    <label>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                      <Button variant="outline" asChild>
                        <span>Browse Files</span>
                      </Button>
                    </label>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <div className="bg-white border-t border-gray-200 px-4 py-4">
        <div className="max-w-2xl mx-auto">
          <Button
            onClick={handleTrain}
            disabled={!canTrain || isTraining}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isTraining ? 'Training Model...' : 'Train Model'}
          </Button>
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import { Send, Wand2 } from 'lucide-react';
import { Button } from './ui/button';
import { Model } from '../App';
import { ModelSelector } from './ModelSelector';

interface InputAreaProps {
  selectedModelName: string;
  onSendMessage: (text: string) => void;
  onInputChange: (text: string) => void;
  inputValue: string;
  disabled?: boolean;
  models: Model[];
  pinnedModelIds: string[];
  selectedModelId: string | null;
  onSelectModel: (modelId: string | null) => void;
  onTrainNewModel: () => void;
  onManagePinned: () => void;
}

export function InputArea({ 
  selectedModelName, 
  onSendMessage,
  onInputChange,
  inputValue,
  disabled = false,
  models,
  pinnedModelIds,
  selectedModelId,
  onSelectModel,
  onTrainNewModel,
  onManagePinned
}: InputAreaProps) {
  const [showModelSelector, setShowModelSelector] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = '52px';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = Math.min(Math.max(scrollHeight, 52), 120) + 'px';
    }
  }, [inputValue]);

  const handleInputChangeInternal = (text: string) => {
    onInputChange(text);
  };

  const handleSend = () => {
    if (inputValue.trim() && !disabled) {
      onSendMessage(inputValue);
      if (textareaRef.current) {
        textareaRef.current.style.height = '52px';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSelectModel = (modelId: string | null) => {
    onSelectModel(modelId);
  };

  const handleTrainNewModel = () => {
    onTrainNewModel();
  };

  const handleManagePinned = () => {
    onManagePinned();
  };

  // Determine which icon to show based on model selection
  const hasModelSelected = selectedModelId && selectedModelId !== 'none';

  return (
    <div className="bg-white border-t border-gray-200">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="mb-2">
          <ModelSelector
            open={showModelSelector}
            onOpenChange={setShowModelSelector}
            models={models}
            pinnedModelIds={pinnedModelIds}
            selectedModelId={selectedModelId}
            selectedModelName={selectedModelName}
            onSelectModel={handleSelectModel}
            onTrainNewModel={handleTrainNewModel}
            onManagePinned={handleManagePinned}
          />
        </div>

        <div className="flex items-end gap-2">
          <textarea
            ref={textareaRef}
            value={inputValue}
            onChange={(e) => handleInputChangeInternal(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message..."
            disabled={disabled}
            className="flex-1 resize-none rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ minHeight: '52px', maxHeight: '120px' }}
          />
          <Button
            onClick={handleSend}
            disabled={!inputValue.trim() || disabled}
            className="h-[52px] px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl"
          >
            {hasModelSelected ? (
              <Wand2 className="w-5 h-5" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
